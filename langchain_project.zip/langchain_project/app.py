"""
Python Doubt Solver - AI Question-Answering Chatbot
Built with LangChain + Google Gemini
"""

import os
import sys

from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI

# 1. Load the API key from the .env file
load_dotenv()

MODEL_NAME = "gemini-2.5-flash"


def build_chain():
    """Connect Gemini to a prompt template and return a runnable chain."""
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        raise ValueError(
            "GOOGLE_API_KEY not found. Add your key to the .env file "
            "(get one free at https://aistudio.google.com/app/apikey)."
        )

    # 2. Language model
    llm = ChatGoogleGenerativeAI(
        model=MODEL_NAME,
        google_api_key=api_key,
        temperature=0.3,
    )

    # 3. Prompt template
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a friendly Python tutor and doubt solver for students. "
                "Explain concepts in simple language, give a short example in "
                "Python code when useful, and keep answers clear and concise. "
                "If the question is not related to Python or programming, "
                "politely say you only help with Python doubts.",
            ),
            ("human", "{question}"),
        ]
    )

    # 4. Chain: prompt -> model -> plain text output
    return prompt | llm | StrOutputParser()


def main():
    print("=" * 55)
    print("        PYTHON DOUBT SOLVER  (LangChain + Gemini)")
    print("=" * 55)
    print("Ask any Python question. Type 'exit' or 'quit' to stop.\n")

    try:
        chain = build_chain()
    except ValueError as err:
        print(f"Setup error: {err}")
        sys.exit(1)
    except Exception as err:
        print(f"Could not initialise the model: {err}")
        sys.exit(1)

    while True:
        try:
            question = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if question.lower() in {"exit", "quit", "q"}:
            print("Goodbye! Happy coding.")
            break

        if not question:
            print("Please type a question.\n")
            continue

        try:
            answer = chain.invoke({"question": question})
            print(f"\nBot: {answer}\n")
        except Exception as err:
            # Covers network issues, invalid key, quota limits, etc.
            print(f"\nSorry, something went wrong: {err}\n")


if __name__ == "__main__":
    main()
